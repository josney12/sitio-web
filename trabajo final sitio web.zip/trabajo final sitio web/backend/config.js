// config.js
module.exports = {
    host: 'brxsw7xlmpeukrblp4fm-mysql.services.clever-cloud.com',
    user: 'uiwfbbptsx8tsa6n',
    password: 'dwWUo6d89iEetKMfYMoL',
    database: 'brxsw7xlmpeukrblp4fm'
};
